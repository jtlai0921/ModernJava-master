public class PrimesDemo {
    public static void main(String[] args) {
        Primes calculator = new Primes();
        System.out.println(calculator.nextPrime(1000));
    }
}
