public interface MyChildInterface extends MyInterface {
    int myOtherMethod();
}
